# Web Scraping World Flags
Taller relacionado a la primera parte del juego tipo QUIZ de Banderas del mundo

## Retos del taller

- [X] [Obtener la información del área y populación en tipo numérico.](https://github.com/mugan86/web-scrapping-world-flags/issues/1)
- [X] [Extraer toda la información de golpe sin hacerlo individualmente.](https://github.com/mugan86/web-scrapping-world-flags/issues/2)
- [X] [Comprobar si existe directorio 'data' y crearlo si no existe.](https://github.com/mugan86/web-scrapping-world-flags/issues/6)
- [ ] [Descargar imágenes de las banderas.](https://github.com/mugan86/web-scrapping-world-flags/issues/3)